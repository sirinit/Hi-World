#include <iostream>
#include <iomanip>
#include <ctime>
#include <sstream>
#include <ctime>
#include <stdio.h>
#include <exception>

#include "SoupFileStore.h"

using namespace std;

namespace SoupBinTcp
{

SoupFileStore::SoupFileStore( SoupBinTcp::ConnectionType type, std::string& name, std::string &file_path )
: m_type( type ),
 m_name( name ),
 m_file_path( file_path )
{
}
SoupFileStore::~SoupFileStore()
{
    this->Close();
}
void SoupFileStore::Open()
{
    //
    // Create Seqnumber file
    std::time_t t = std::time(nullptr);
    std::tm tm = *std::localtime(&t);
    stringstream ss;
    //
    // Open sequence file
    if ( m_type == ConnectionType::CLIENT )
        ss << m_file_path << "SoupClient_" << m_name << "_" << std::put_time(&tm, "%Y%m%d") << ".seqnum";
    else
        ss << m_file_path << "SoupServer_" << m_name << "_" << std::put_time(&tm, "%Y%m%d") << ".seqnum";

    m_seq_file_name = ss.str();

    m_seq_file =  fopen(m_seq_file_name.c_str(), "r+" );
    if ( m_seq_file == nullptr )
    {
        m_seq_file =  fopen( m_seq_file_name.c_str(), "w+" );
        if ( m_seq_file == nullptr)
        {
            ss.str(""); ss.clear();
            ss << "Could not open sequence file: " << m_seq_file_name;
            throw runtime_error( ss.str() );
        }
    }
    ss.str(""); ss.clear();
    //
    // Open session file
    if ( m_type == ConnectionType::CLIENT )
        ss << m_file_path << "SoupClient_" << m_name << "_" << std::put_time(&tm, "%Y%m%d") << ".session";
    else
        ss << m_file_path << "SoupServer_" << m_name << "_" << std::put_time(&tm, "%Y%m%d") << ".session";

    m_session_file_name = ss.str();

    m_session_file = fopen( m_session_file_name.c_str(), "r+" );
    if ( m_session_file == nullptr )
    {
        m_session_file =  fopen( m_session_file_name.c_str(), "w+" );
        if ( m_session_file == nullptr )
        {
            ss.str(""); ss.clear();
            ss << "Could not open session file: " << m_session_file_name;
            throw runtime_error( ss.str() );
        }
    }
}
uint64_t SoupFileStore::ReadSeqNoFile( )
{
    uint64_t seqnum = 0;
    rewind( m_seq_file );
    fscanf( m_seq_file, "%ld", &seqnum  );
    return seqnum;
}

void SoupFileStore::WriteSeqNoFile( uint64_t seqno )
{
    rewind( m_seq_file );
    fprintf( m_seq_file, "%ld", seqno );
}
std::string SoupFileStore::ReadSessionFile()
{
    char session[50];
    session[0] = 0;
    fscanf( m_session_file, "%s", session );
    return std::string( session );
}
void SoupFileStore::WriteSessionFile( std::string &session )
{
    rewind( m_session_file );
    fprintf( m_session_file, "%s", session.c_str() );
}
void SoupFileStore::Close()
{
    if ( m_session_file != nullptr)
    {
        fclose ( m_session_file );
        m_session_file = nullptr;
    }
    if ( m_seq_file != nullptr )
    {
        fclose( m_seq_file );
        m_seq_file = nullptr;
    }
}

}
