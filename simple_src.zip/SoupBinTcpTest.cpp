#include <iostream>
#include <memory>

#include "SoupBinTcp.h"
#include "SoupBinTcpApplication.h"
#include "SoupBinTcpClient.h"

using namespace std;
using namespace SoupBinTcp;

class SoupBinTcpTest: public SoupBinTcp::SoupBinTcpApplication {
public:
    SoupBinTcpTest() {
    }
    ;
    ~SoupBinTcpTest() {
    }
    ;
    /// Notification of a session successfully logging on
    void onTcpConnnected(std::string& name, std::string& ip_address,
            unsigned short remote_port) {
        printf("\n------ %s connected to %s %d\n", name.c_str(),
                ip_address.c_str(), remote_port);
    }
    /// Notification of a session logging off or disconnecting
    void onTcpDisconnected(std::string& name, std::string& ip_address,
            unsigned short remote_port) {
        printf("\n------ %s disconnected to %s %d\n", name.c_str(),
                ip_address.c_str(), remote_port);
    }

    /// Notification of app message being received from target
    void OnReceived(std::string& name, const char packet_type, const char *msg,
            int msg_len) {
        printf("\n------ Received <%s>\n", msg);
    }

    /// Before send anything.
    void OnSent(std::string& name, int function_code, const char *msg,
            int msg_len)            {
    }

    void OnRetryingToConnect(std::string& name, const char* notify_msg)
    {
        printf("\n------ notify: %s\n", notify_msg );
    }
    void OnNotifyError( const char* notify_msg)
    {
        printf("\n------ SoupBinTcp report an error: %s\n", notify_msg );
    }
    void OnReadyToSend()
    {
        printf("\n------ SoupBinTcp is ready to send\n");
    }
};

int main() {
    SoupBinTcpTest app;
    SoupBinTcpConfig config;

    config.user_name = "login";
    config.password = "secret";
    config.remote_ip_address = "127.0.0.1";
    config.remote_port = 5001;
    config.listen_port = 5001;
    config.session = "Session01";
    config.store_path = "";
    string name = "CHX";

    shared_ptr<SoupBinTcpClient> client( new SoupBinTcpClient( name, config, app ) );
    cout << "This is the last line" << endl;
    return 0;

}
