#pragma once
#include <map>
#include <string>
#include <cstdint>

namespace SoupBinTcp
{

enum class ConnectionStatus : int {
   CLOSED,
   CONNECTING,
   CONNECTED,
   ACCEPTING
};
static std::map<int, std::string> map_connection_status_str =
 { {0, "CLOSED"}, {1, "CONNECTING"}, {2, "CONNECTED"}, {3, "ACCEPTING"} };

enum class ConnectionType :int {
   SERVER = 0,
   CLIENT = 1
};

const unsigned short MAX_PAYLOAD_SIZE = 4096;

namespace PacketType
{
   const char DEBUG  = '+';
   const char LOGIN_ACCPEPT = 'A';
   const char LOGIN_REJECT = 'J';
   const char SEQ_DATA = 'S';
   const char UNSEQ_DATA = 'U';
   const char SERVER_HEARTBEAT = 'H';
   const char END_SESSION = 'Z';
   const char LOGIN_REQUEST = 'L';
   const char CLIENT_HEARTBEAT = 'R';
   const char LOGOUT_REQUEST = 'O';
}
namespace RejectCode
{
   const char INV_USRPWD = 'A';
   const char INV_SESSION = 'S';
}

#pragma pack(push, 1)

typedef struct _MsgHeader
{
   unsigned short  msg_len;
   char            packet_type;
} MsgHeader;

typedef struct _DebugPacket
{
   MsgHeader   header;
   char        debug_msg[MAX_PAYLOAD_SIZE];
} DebugPacket;

typedef struct _LogonAcceptPacket
{
   MsgHeader   header;
   char        session[10];
   char        seqno[20];
} LogonAcceptPacket;

typedef struct _LogonRejectPacket
{
   MsgHeader   header;
   char        reject_code;
} LogonRejectPacket;

typedef struct _SeqPacket
{
   MsgHeader   header;
   char        msg[MAX_PAYLOAD_SIZE];
} SeqPacket;

typedef struct _UnSeqPacket
{
   MsgHeader   header;
   char        msg[MAX_PAYLOAD_SIZE];
} UnSeqPacket;

typedef struct _LogonRequestPacket
{
   MsgHeader   header;
   char        user_name[6];
   char        password[10];
   char        req_session[10];
   char        req_seqno[20];
} LogonRequestPacket;

typedef union _SOUPBINTCP_DATA 
{
   MsgHeader            hdr;  // use for any message that contain only header
   DebugPacket          debug;
   LogonAcceptPacket    logon_ok;
   LogonRejectPacket    logon_rej;
   SeqPacket            seqmsg;
   UnSeqPacket          unseqmsg;
   LogonRequestPacket   logon_req;
} SOUPBINTCP_DATA;

#pragma pack(pop)

typedef struct _SoupBinTcpConfig
{
   std::string user_name;
   std::string password;
   std::string remote_ip_address;
   unsigned short remote_port;
   unsigned short listen_port;
   std::string session;
   std::string store_path;
} SoupBinTcpConfig;

typedef struct _SoupConnectionStatus
{
   std::string type;
   std::string name;
   std::string session;
   ConnectionStatus status;
   std::string remote_ip_address;
   unsigned short remote_port;
   unsigned short listen_port;
   uint64_t last_received_seqno;
   uint64_t last_sent_seqno;
   uint64_t total_sent_unseq;
   uint64_t total_sent_heartbeat;
   uint64_t total_sent_debug;
   uint64_t total_receive_unseq;
   uint64_t total_receive_heartbeat;
   uint64_t total_receive_debug;
   bool is_ready_to_send;
} SoupConnectionStatus;

}
