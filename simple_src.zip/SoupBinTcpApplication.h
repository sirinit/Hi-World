#pragma once

#include <string>


namespace SoupBinTcp
{
  
class SoupBinTcpApplication
{
public:
  virtual ~SoupBinTcpApplication() {};
  virtual void OnNotifyError( const char * notify_msg ) = 0;
  /// Notification of a session successfully logging on
  virtual void onTcpConnnected( std::string& name, std::string& ip_address, unsigned short remote_port ) = 0;
  /// Notification of a session logging off or disconnecting
  virtual void onTcpDisconnected( std::string& name, std::string& ip_address, unsigned short remote_port ) = 0;
  /// Notification of app message being received from target
  virtual void OnReceived( std::string& name, const char packet_type, const char *msg, int msg_len ) = 0;
  /// Before send anything.
  virtual void OnSent( std::string& name, int function_code, const char *msg, int msg_len ) = 0;
  virtual void OnRetryingToConnect( std::string& name, const char * notify_msg ) = 0;
  virtual void OnReadyToSend() = 0;
};

} 

