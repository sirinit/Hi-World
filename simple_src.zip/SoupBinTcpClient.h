#pragma once

#include <boost/asio.hpp>
#include <thread>
#include "SoupBinTcp.h"
#include "SoupBinTcpApplication.h"
#include "SoupFileStore.h"

namespace SoupBinTcp
{

class SoupBinTcpClient
{
public:
   SoupBinTcpClient( std::string& name, SoupBinTcpConfig &config,
      SoupBinTcpApplication& app );
   ~SoupBinTcpClient();
   int Connect();
   int Connect( std::string& remote_ip_address, unsigned short remote_port );
   int Close();
   //
   //
   int SendDebugMsg(const void *payload_msg, unsigned short msg_len );
   int SendUnSeqMsg(const void *payload_msg, unsigned short msg_len );
   int SendLogOnlyUnSeqMsg(const void *payload_msg, unsigned short msg_len );
   void GetStatus( SoupConnectionStatus &status );

protected:

   void ConnectHandler( const boost::system::error_code& error );
   void RetryTimerHandler( const boost::system::error_code& error );
   void RunIoThread();
   void Read();
   int SendMsg( SOUPBINTCP_DATA &msg, unsigned short msg_len );
   void ProcessLogonAcceptMsg( LogonAcceptPacket *logon );
   int ProcessIncoming( const char *msg, int msg_len );
   void Heartbeat();
private:
   std::string             m_name;
   SoupBinTcpApplication&  m_app;
   boost::asio::io_service                  m_io_service;
   boost::asio::ip::tcp::socket             m_socket;
   boost::asio::ip::tcp::endpoint           m_remote_endpoint;
   std::string             m_remote_address;
   unsigned short          m_remote_port;

   ConnectionStatus     m_status = ConnectionStatus::CLOSED;
   boost::asio::deadline_timer   m_retry_timer;
   std::string m_user_name;
   std::string m_password;
   std::string m_file_path;
   std::string m_cur_session;
   bool m_ready_to_send = false;
   SoupFileStore m_file_store;
   time_t   m_last_receive_time = 0;
   bool m_end_of_session = false;
   std::thread m_heartbeat;
   uint64_t m_last_receive_seqno = 0;
   uint64_t m_total_sent_unseq;
   uint64_t m_total_sent_heartbeat;
   uint64_t m_total_sent_debug;
   uint64_t m_total_receive_unseq;
   uint64_t m_total_receive_heartbeat;
   uint64_t m_total_receive_debug;
   bool m_stopping = false;

};
}
