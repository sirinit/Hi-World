#include <stdlib.h>
#include <sstream>
#include "SoupBinTcp.h"
#include "SoupBinTcpClient.h"
#include <chrono>
#include <thread>
#include <boost/asio.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

using boost::asio::ip::tcp;
using namespace std;

namespace SoupBinTcp
{
//
// For Client
SoupBinTcpClient::SoupBinTcpClient( std::string& name, SoupBinTcpConfig &config,
                                     SoupBinTcpApplication& app)
: m_name( name ),
 m_app( app ),
 m_socket( m_io_service ),
 m_remote_endpoint( boost::asio::ip::address::from_string( config.remote_ip_address ), config.remote_port ),
 m_retry_timer( m_io_service ),
 m_file_store( ConnectionType::CLIENT, name, config.store_path )
{
    m_remote_address = config.remote_ip_address;
    m_remote_port = config.remote_port;
    m_user_name = config.user_name;
    m_password = config.password;
    m_file_path = config.store_path;
   m_total_sent_unseq = 0;
   m_total_sent_heartbeat = 0;
   m_total_sent_debug = 0;
   m_total_receive_unseq = 0;
   m_total_receive_heartbeat = 0;
   m_total_receive_debug = 0;

   m_file_store.Open();
   // load session and seqnum
   m_last_receive_seqno = m_file_store.ReadSeqNoFile();
   m_cur_session = m_file_store.ReadSessionFile();
   //
   // Start heartbeat
   m_heartbeat = thread( &SoupBinTcpClient::Heartbeat, this );


}
SoupBinTcpClient::~SoupBinTcpClient()
{
   try
   {
        m_stopping = true;
        this->Close();
        m_heartbeat.join();
        m_file_store.Close();
        m_io_service.stop();
   }
   catch (...)
   {
   }
}

int SoupBinTcpClient::Connect( std::string& remote_ip_address, unsigned short remote_port )
{
   m_remote_address = remote_ip_address;
   m_remote_port = remote_port;
   m_remote_endpoint = boost::asio::ip::tcp::endpoint( boost::asio::ip::address::from_string( remote_ip_address ), remote_port );
   return this->Connect();
}

int SoupBinTcpClient::Connect()
{
   //
   // It is done for the day if end of session
   if ( m_end_of_session )
      return 0;
   //
   // If we are trying to connect or already connected then don't do it.
   if ( m_status != ConnectionStatus::CLOSED )
      return 0;

   m_status = ConnectionStatus::CONNECTING;
   m_io_service.reset(); // we need to reset the io_service otherwise it will not going to work for reconnecting.
   m_socket.async_connect( m_remote_endpoint, [this] (boost::system::error_code ec) { this->ConnectHandler( ec ); } );

   // report every 2 seconds
   m_retry_timer.expires_from_now( boost::posix_time::seconds(2) );
   m_retry_timer.async_wait( [this] (boost::system::error_code ec) { this->RetryTimerHandler(ec);} );

   //
   // Start retrying on the other thread. It will stop after connecting or someone call stop
   thread io_thread =  thread( &SoupBinTcpClient::RunIoThread, this );
   io_thread.detach(); // don't care about it
   return 0;
}

int SoupBinTcpClient::Close()
{
   try
   {
      m_ready_to_send = false;
      m_status = ConnectionStatus::CLOSED;
      m_socket.close();
   }
   catch (...)
   {
   }
   return 0;
}

void SoupBinTcpClient::Read()
{
   unsigned short msg_len;
   char msg_buf[1024*64];
   boost::system::error_code error;
   size_t read_len;
   char error_msg[200];

   try
   {
      while ( m_status == ConnectionStatus::CONNECTED )
      {
         // First read size of the message
         read_len = m_socket.read_some(boost::asio::buffer(&msg_len, sizeof( unsigned short) ), error);
         if ( error || (read_len != sizeof( unsigned short)) )
         {
            if ( !error )
            {
               sprintf( error_msg, "Network message less than expected: get: %ld, expected: %ld", read_len, sizeof( unsigned short ) );
               m_app.OnNotifyError( error_msg );
            }
            break;
         }
         memcpy( msg_buf, &msg_len, sizeof( unsigned short) );
         msg_len = ntohs( msg_len );
         read_len = m_socket.read_some(boost::asio::buffer(&msg_buf[sizeof( unsigned short)], msg_len ), error);
         if ( error || (read_len != msg_len) )
         {
            if ( !error )
            {
               sprintf( error_msg, "Network message less than expected: get: %ld, expected: %ld", read_len, sizeof( unsigned short ) );
               m_app.OnNotifyError( error_msg );
            }
            break;
         }
         //
         // Now we got the data;
         msg_buf[msg_len + sizeof( unsigned short)] = 0;
         if ( this->ProcessIncoming( msg_buf, msg_len + sizeof( unsigned short) ) )
         {
            // There is error on the message then close the connection
            break;
         }
      }
   }
   catch (std::exception& e)
   {
      m_app.OnNotifyError( e.what() );
   }
   if ( m_status == ConnectionStatus::CONNECTED )
   {
      //
      // The other side disconnect to us so try to reconnect
      this->Close();
      //
      // Report disconnected 
      m_app.onTcpDisconnected( m_name, m_remote_address, m_remote_port );
      //
      // wait for 2 seconds before reconnecting
      boost::asio::deadline_timer t(m_io_service, boost::posix_time::seconds(2));      
      t.wait();
      this->Connect();
   }
}


void SoupBinTcpClient::ConnectHandler( const boost::system::error_code& error )
{
   if ( m_status != ConnectionStatus::CONNECTING )
      return;  // the application may decided to stop retrying the connection
   if ( !error )
   {
      m_status = ConnectionStatus::CONNECTED;
      // We got the connection
      m_app.onTcpConnnected( m_name, m_remote_address, m_remote_port );
      //
      // We should start reading data from socket.
      thread read_thread = thread( &SoupBinTcpClient::Read, this);
      read_thread.detach(); // it will die when it get read i/o error
      // Send logon request
      SOUPBINTCP_DATA logon;
      memset( &logon, ' ', sizeof( LogonRequestPacket ));
      logon.hdr.packet_type = PacketType::LOGIN_REQUEST;
      memcpy( logon.logon_req.user_name, m_user_name.c_str(), m_user_name.length() );
      memcpy( logon.logon_req.password,  m_password.c_str(), m_password.length() );
      memcpy( logon.logon_req.req_session,  m_cur_session.c_str(), m_cur_session.length() );

      //
      // If there is no last_receive_seq then start with zero to get the latest of current session
      // there is no retransmit.
      uint64_t next_req_seqno = 0;
      if ( m_last_receive_seqno )
         next_req_seqno =  m_last_receive_seqno + 1;

      std::string last_seq = static_cast<ostringstream*>( &(ostringstream() << setw(sizeof( logon.logon_req.req_seqno )) << next_req_seqno) )->str();      
      memcpy( logon.logon_req.req_seqno, last_seq.c_str(), last_seq.length() ); 
      logon.hdr.msg_len = htons( sizeof( logon.logon_req ) - sizeof(unsigned short) );
      this->SendMsg( logon, sizeof( logon.logon_req ) );
      //
      // Start checking idle time
      time( &m_last_receive_time );
   }
   else
   {
      // keep trying to make the connection
      m_retry_timer.async_wait( [this] (boost::system::error_code ec) { this->RetryTimerHandler(ec);} );
      m_socket.async_connect( m_remote_endpoint, [this] (boost::system::error_code ec) { this->ConnectHandler(ec);} );
   }
}
void SoupBinTcpClient::RetryTimerHandler( const boost::system::error_code& error )
{
   if ( !error  && (m_status == ConnectionStatus::CONNECTING) )
   {
      char log_msg[100];
      sprintf( log_msg, "Trying to connect to %s port %d", m_remote_address.c_str(), m_remote_port );
      m_app.OnRetryingToConnect( m_name, log_msg );
      //
      // Keep reporting
      m_retry_timer.expires_from_now( boost::posix_time::seconds(2) );
      m_retry_timer.async_wait( [this] (boost::system::error_code ec) { this->RetryTimerHandler(ec);} );
   }
}
void SoupBinTcpClient::RunIoThread()
{
   m_io_service.run();
}
int SoupBinTcpClient::SendDebugMsg(const void *payload_msg, unsigned short msg_len )
{
   SOUPBINTCP_DATA msg;
   unsigned short net_msg_len = msg_len + sizeof( msg.hdr ); // for packet size
   msg.hdr.msg_len = htons( msg_len + 1 );
   msg.hdr.packet_type = PacketType::DEBUG;
   memcpy( msg.debug.debug_msg, payload_msg, msg_len );
   this->SendMsg( msg, net_msg_len );
   m_total_sent_debug++;
   return 0;
}

int SoupBinTcpClient::SendUnSeqMsg(const void *payload_msg, unsigned short msg_len )
{
   if ( !m_ready_to_send )
   {
      m_app.OnNotifyError( "Connection is not ready to send" );
      return 1;
   }
   SOUPBINTCP_DATA msg;
   unsigned short net_msg_len = msg_len + sizeof( msg.hdr ); // for packet size
   msg.hdr.msg_len = htons( msg_len + 1 );
   msg.hdr.packet_type = PacketType::UNSEQ_DATA;
   memcpy( msg.debug.debug_msg, payload_msg, msg_len );
   this->SendMsg( msg, net_msg_len );
   m_total_sent_unseq++;
   return 0;
}

int SoupBinTcpClient::SendLogOnlyUnSeqMsg(const void *payload_msg, unsigned short msg_len )
{
   SOUPBINTCP_DATA msg;
//   unsigned short net_msg_len = msg_len + sizeof( msg.hdr ); // for packet size
   msg.hdr.msg_len = htons( msg_len + 1 );
   msg.hdr.packet_type = PacketType::UNSEQ_DATA;
   memcpy( msg.debug.debug_msg, payload_msg, msg_len );

   m_total_sent_unseq++;
   return 0;
}

int SoupBinTcpClient::SendMsg( SOUPBINTCP_DATA &msg, unsigned short msg_len )
{
   boost::system::error_code ignored_error;

   boost::asio::write(m_socket, boost::asio::buffer( (const void *)&msg, msg_len ), ignored_error);

   return 0;
}

int SoupBinTcpClient::ProcessIncoming( const char *msg, int msg_len )
{
   time( &m_last_receive_time );

   SOUPBINTCP_DATA *soup_msg = (SOUPBINTCP_DATA *)msg;

   switch ( soup_msg->hdr.packet_type )
   {
   case PacketType::LOGIN_REJECT:
      {
      if ( msg_len != sizeof( LogonRejectPacket ) )
      {
         char error_msg[100];
         sprintf( error_msg, "Invalid message size of Logon Reject: get: %d, expected: %ld", msg_len, sizeof( LogonRequestPacket ) );
         m_app.OnNotifyError( error_msg );
         return 1;
      }
      LogonRejectPacket *rej_msg = (LogonRejectPacket *)msg;
      if ( rej_msg->reject_code == RejectCode::INV_USRPWD )
         m_app.OnNotifyError( "Server reply invalid username or password");
      else 
         m_app.OnNotifyError( "Server reply invalid session name" );
      }
      break;
   case PacketType::LOGIN_ACCPEPT:
      {
      if ( msg_len != sizeof( LogonAcceptPacket ) )
      {
         char error_msg[100];
         sprintf( error_msg, "Invalid message size of Logon Accept: get: %d, expected: %ld", msg_len, sizeof( LogonRequestPacket ) );
         m_app.OnNotifyError( error_msg );
         return 1;
      }
      ProcessLogonAcceptMsg( (LogonAcceptPacket *)soup_msg );
      }
      break;
   case PacketType::SEQ_DATA:
      {
      SeqPacket *seq_msg = (SeqPacket *)msg;
      m_last_receive_seqno++;
      m_app.OnReceived( m_name, PacketType::SEQ_DATA, seq_msg->msg, msg_len - sizeof( MsgHeader ) );
      m_file_store.WriteSeqNoFile( m_last_receive_seqno );
      break;
      }
   case PacketType::DEBUG:
      {
      DebugPacket *debug_msg = (DebugPacket *)msg;
      m_app.OnReceived( m_name, PacketType::DEBUG, debug_msg->debug_msg, msg_len - sizeof( MsgHeader ) );
      m_total_receive_debug++;
      break;
      }
   case PacketType::UNSEQ_DATA:
      {
      UnSeqPacket *unseq_msg = (UnSeqPacket *)msg;
      m_app.OnReceived( m_name, PacketType::UNSEQ_DATA, unseq_msg->msg, msg_len - sizeof( MsgHeader ) );
      m_total_receive_unseq++;
      break;
      }
   case PacketType::SERVER_HEARTBEAT:
      {
      // do nothing
      m_total_receive_heartbeat++;
      break;
      }
   case PacketType::END_SESSION:
      {
      m_app.OnNotifyError( "Received End of Session message" );
      m_end_of_session = true;
      break;
      }
   default:
      {
         char error_msg[100];
         sprintf( error_msg, "Unknown packet type %c", soup_msg->hdr.packet_type );
         m_app.OnNotifyError( error_msg );
         break;
      }
   }
   return 0;
}

void SoupBinTcpClient::ProcessLogonAcceptMsg( LogonAcceptPacket *logon )
{
   //
   // Update session nanme to file
   // Update last receive sequence number in cache and file.
   // Turn on ready_to_send flag

   char temp[30];
   memcpy( temp, logon->session, sizeof( logon->session ) );
   temp[ sizeof( logon->session ) ] = 0;
   m_cur_session = temp;
   m_file_store.WriteSessionFile( m_cur_session );

   memcpy( temp, logon->seqno, sizeof( logon->seqno ) );
   temp[ sizeof( logon->seqno ) ] = 0;
   //
   // the logon->seqno is the next seq that server will send to client
   // In client we keep last received seqno
   m_last_receive_seqno = atol( temp ) - 1;
   m_file_store.WriteSeqNoFile( m_last_receive_seqno );
   m_ready_to_send = true;
   m_app.OnReadyToSend();

}

void SoupBinTcpClient::Heartbeat()
{
   while ( !m_stopping )
   {
      if ( (m_status == ConnectionStatus::CONNECTED) && !m_end_of_session )
      {
         //
         // Check idle time
         time_t now;
         time( &now );
         double second = difftime( now, m_last_receive_time );
         if ( second > 5.0 )
         {
            m_app.OnNotifyError( "No activity from server for 5 seconds, so close the connection");
            this->Close();
            //
            // wait for 2 seconds before reconnecting
            std::this_thread::sleep_for( std::chrono::seconds(2) );
            this->Connect();
         }
         else
         {
            //
            // Send heartbeat
            SOUPBINTCP_DATA heartbeat;
            memset( &heartbeat, ' ', sizeof( MsgHeader ));
            heartbeat.hdr.packet_type = PacketType::CLIENT_HEARTBEAT;
            heartbeat.hdr.msg_len = htons( sizeof( MsgHeader ) - sizeof(unsigned short) );
            this->SendMsg( heartbeat, sizeof( MsgHeader ) );
            m_total_sent_heartbeat++;
         }
      }
      std::this_thread::sleep_for(std::chrono::seconds(1));
   }
}

void SoupBinTcpClient::GetStatus( SoupConnectionStatus &status )
{
   status.type = "Client";
   status.name = m_name;
   status.last_received_seqno = m_last_receive_seqno;
   status.last_sent_seqno = 0;
   status.listen_port = 0;
   status.remote_ip_address = m_remote_address;
   status.remote_port = m_remote_port;
   status.session = m_cur_session;
   status.total_receive_debug = m_total_receive_debug;
   status.total_receive_heartbeat = m_total_receive_heartbeat;
   status.total_receive_unseq = m_total_receive_unseq;
   status.total_sent_debug = m_total_sent_debug;
   status.total_sent_unseq = m_total_sent_unseq;
   status.total_sent_heartbeat = m_total_sent_heartbeat;
   status.status = m_status;
   status.is_ready_to_send = m_ready_to_send;
}

}
