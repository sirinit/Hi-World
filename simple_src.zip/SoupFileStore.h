#pragma once
#include <cstdint>
#include "SoupBinTcp.h"

namespace SoupBinTcp
{

class SoupFileStore
{
public:
   SoupFileStore( ConnectionType type, std::string& name, std::string &file_path );
   ~SoupFileStore();

   void Open();
   uint64_t ReadSeqNoFile( );
   void WriteSeqNoFile( uint64_t seqno );
   std::string ReadSessionFile();
   void WriteSessionFile( std::string &session );
   void Close();

protected:

private:
   SoupBinTcp::ConnectionType    m_type;
   std::string                   m_name;
   std::string                   m_file_path;
   std::string                   m_seq_file_name;
   std::string                   m_session_file_name;
   FILE*                         m_seq_file = nullptr;
   FILE*                         m_session_file = nullptr;

};
}

